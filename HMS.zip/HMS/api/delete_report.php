<?php
include '../includes/db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $stmt = $conn->prepare("DELETE FROM reports WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: ../reports.php?deleted=1");
        exit();
    } else {
        echo "Error deleting report: " . $stmt->error;
    }
}
?>

