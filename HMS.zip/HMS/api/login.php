<?php
session_start();

// ✅ Correct path to db.php from inside /api folder
include '../includes/db.php';

// ✅ Ensure form data exists
if (!isset($_POST['username']) || !isset($_POST['password'])) {
    die("Username and password required.");
}

$username = mysqli_real_escape_string($conn, $_POST['username']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

// ✅ Fetch user from database
$query = "SELECT * FROM users WHERE username = '$username' LIMIT 1";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) === 1) {
    $user = mysqli_fetch_assoc($result);

    // ✅ Password check - use plain text or password_verify() based on your DB
    if (password_verify($password, $user['password']) || $password === $user['password']) {
        $_SESSION['user'] = $user;
        header("Location: ../dashboard.php");
        exit();
    } else {
        // Incorrect password
        header("Location: ../login.php?error=Invalid Password");
        exit();
    }
} else {
    // No user found
    header("Location: ../login.php?error=User Not Found");
    exit();
}