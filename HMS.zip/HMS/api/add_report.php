<?php
include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = $_POST['patient_id'];
    $doctor_id = $_POST['doctor_id'];
    $report_type = $_POST['report_type'];
    $report_date = $_POST['report_date'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO reports (patient_id, doctor_id, report_type, report_date, description) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisss", $patient_id, $doctor_id, $report_type, $report_date, $description);

    if ($stmt->execute()) {
        header("Location: ../reports.php?success=1");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
