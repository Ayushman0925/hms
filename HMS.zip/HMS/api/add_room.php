<?php
include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $room_number = $_POST['room_number'];
    $room_type = $_POST['room_type'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("INSERT INTO rooms (room_number, room_type, status) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $room_number, $room_type, $status);

    if ($stmt->execute()) {
        header("Location: ../room.php?success=1");
    } else {
        header("Location: ../room.php?error=1");
    }

    $stmt->close();
    $conn->close();
}
?>