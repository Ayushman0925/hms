<?php
include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $type = $_POST['type'];
    $manufacturer = $_POST['manufacturer'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    $stmt = $conn->prepare("INSERT INTO medicines (name, type, manufacturer, price, stock) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssdi", $name, $type, $manufacturer, $price, $stock);

    if ($stmt->execute()) {
        header("Location: ../medicines.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
