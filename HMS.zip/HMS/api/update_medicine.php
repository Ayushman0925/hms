<?php
include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $type = $_POST['type'];
    $manufacturer = $_POST['manufacturer'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    $stmt = $conn->prepare("UPDATE medicines SET name=?, type=?, manufacturer=?, price=?, stock=? WHERE id=?");
    $stmt->bind_param("sssdii", $name, $type, $manufacturer, $price, $stock, $id);

    if ($stmt->execute()) {
        header("Location: ../medicines.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
