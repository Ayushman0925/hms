<?php
include '../includes/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $department = $_POST['department'];

    $sql = "UPDATE nurses SET 
            name='$name', gender='$gender', contact='$contact',
            email='$email', department='$department' WHERE id=$id";
    mysqli_query($conn, $sql);
    header("Location: ../nurse.php");
}
?>