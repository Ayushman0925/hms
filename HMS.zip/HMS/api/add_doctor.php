<?php
include '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $specialization = mysqli_real_escape_string($conn, $_POST['specialization']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);

    $query = "INSERT INTO doctors (name, specialization, contact, email, department)
              VALUES ('$name', '$specialization', '$contact', '$email', '$department')";

    if (mysqli_query($conn, $query)) {
        header("Location: ../doctor.php?success=1");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>