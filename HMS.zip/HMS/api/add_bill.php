<?php
include '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patient_name = $_POST['patient_name'];
    $amount = $_POST['amount'];
    $bill_date = $_POST['bill_date'];
    $status = $_POST['status'];

    $query = "INSERT INTO billing (patient_name, amount, bill_date, status)
              VALUES ('$patient_name', '$amount', '$bill_date', '$status')";

    if (mysqli_query($conn, $query)) {
        header("Location: ../billing.php");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
