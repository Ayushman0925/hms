<?php
include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_name = $_POST['patient_name'];
    $doctor_name = $_POST['doctor_name'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $reason = $_POST['reason'];

    $query = "INSERT INTO appointments (patient_name, doctor_name, appointment_date, appointment_time, reason)
              VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssss", $patient_name, $doctor_name, $appointment_date, $appointment_time, $reason);

    if ($stmt->execute()) {
        header("Location: ../appointments.php");
    } else {
        echo "Error adding appointment: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>