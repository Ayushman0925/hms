<?php
include '../includes/db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "DELETE FROM doctors WHERE id = $id";

    if (mysqli_query($conn, $query)) {
        header("Location: ../doctor.php?deleted=1");
    } else {
        echo "Error deleting doctor: " . mysqli_error($conn);
    }
}
?>