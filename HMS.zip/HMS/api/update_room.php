<?php
include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $room_number = $_POST['room_number'];
    $room_type = $_POST['room_type'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE rooms SET room_number = ?, room_type = ?, status = ? WHERE id = ?");
    $stmt->bind_param("sssi", $room_number, $room_type, $status, $id);

    if ($stmt->execute()) {
        header("Location: ../room.php?updated=1");
    } else {
        header("Location: ../room.php?error=1");
    }

    $stmt->close();
    $conn->close();
}
?>