<?php
include '../includes/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $department = $_POST['department'];

    $sql = "INSERT INTO nurses (name, gender, contact, email, department) 
            VALUES ('$name', '$gender', '$contact', '$email', '$department')";
    mysqli_query($conn, $sql);
    header("Location: ../nurse.php");
}
?>