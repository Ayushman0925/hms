<?php
include '../includes/db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $age = (int) $_POST['age'];
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $disease = mysqli_real_escape_string($conn, $_POST['disease']);
    $doctor_id = (int) $_POST['doctor_id'];
    $room_no = (int) $_POST['room_no'];
    $admission_date = mysqli_real_escape_string($conn, $_POST['admission_date']);

    $sql = "INSERT INTO patients (name, age, gender, disease, doctor_id, room_no, admission_date)
            VALUES ('$name', $age, '$gender', '$disease', $doctor_id, $room_no, '$admission_date')";

    if (mysqli_query($conn, $sql)) {
        header("Location: ../patients.php?success=1");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>