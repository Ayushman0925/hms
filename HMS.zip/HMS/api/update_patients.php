<?php
include '../includes/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    $sql = "UPDATE patients SET 
            name='$name', gender='$gender', contact='$contact',
            email='$email', address='$address' WHERE id=$id";
    mysqli_query($conn, $sql);
    header("Location: ../patient.php");
}
?>