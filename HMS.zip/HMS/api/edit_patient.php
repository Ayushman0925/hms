<?php
include 'includes/db.php';
session_start();

if (!isset($_GET['id'])) {
    header("Location: patients.php");
    exit();
}

$id = (int) $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM patients WHERE id = $id");
$patient = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Patient</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include 'includes/header.php'; ?>
<?php include 'includes/sidebar.php'; ?>

<div class="container mt-4">
    <h3>✏ Edit Patient Info</h3>
    <form method="POST" action="api/update_patient.php">
        <input type="hidden" name="id" value="<?= $patient['id'] ?>">

        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($patient['name']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Age</label>
            <input type="number" name="age" class="form-control" value="<?= $patient['age'] ?>" required>
        </div>
        <div class="mb-3">
            <label>Gender</label>
            <select name="gender" class="form-control" required>
                <option value="male" <?= $patient['gender'] === 'male' ? 'selected' : '' ?>>Male</option>
                <option value="female" <?= $patient['gender'] === 'female' ? 'selected' : '' ?>>Female</option>
                <option value="other" <?= $patient['gender'] === 'other' ? 'selected' : '' ?>>Other</option>
            </select>
        </div>
        <div class="mb-3">
            <label>Disease</label>
            <input type="text" name="disease" class="form-control" value="<?= htmlspecialchars($patient['disease']) ?>">
        </div>
        <div class="mb-3">
            <label>Doctor</label>
            <select name="doctor_id" class="form-control" required>
                <?php
                $doctors = mysqli_query($conn, "SELECT id, name FROM doctors");
                while ($doc = mysqli_fetch_assoc($doctors)) {
                    $selected = $doc['id'] == $patient['doctor_id'] ? 'selected' : '';
                    echo "<option value='{$doc['id']}' $selected>{$doc['name']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Room No</label>
            <input type="number" name="room_no" class="form-control" value="<?= $patient['room_no'] ?>">
        </div>
        <div class="mb-3">
            <label>Admission Date</label>
            <input type="date" name="admission_date" class="form-control" value="<?= $patient['admission_date'] ?>">
        </div>

        <button type="submit" class="btn btn-primary">Update Patient</button>
        <a href="patients.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

</body>
</html>