<?php
include '../includes/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    $sql = "INSERT INTO patients (name, gender, contact, email, address) 
            VALUES ('$name', '$gender', '$contact', '$email', '$address')";
    mysqli_query($conn, $sql);
    header("Location: ../patient.php");
}
?>