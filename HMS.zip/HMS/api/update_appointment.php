<?php
include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $patient_name = $_POST['patient_name'];
    $doctor_name = $_POST['doctor_name'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $reason = $_POST['reason'];

    $query = "UPDATE appointments SET 
                patient_name = ?, 
                doctor_name = ?, 
                appointment_date = ?, 
                appointment_time = ?, 
                reason = ?
              WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssssi", $patient_name, $doctor_name, $appointment_date, $appointment_time, $reason, $id);

    if ($stmt->execute()) {
        header("Location: ../appointments.php");
    } else {
        echo "Error updating appointment: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>