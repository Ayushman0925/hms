<?php
include '../includes/db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM appointments WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: ../appointments.php");
    } else {
        echo "Error deleting appointment: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>