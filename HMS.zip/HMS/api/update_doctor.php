<?php
include '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $specialization = mysqli_real_escape_string($conn, $_POST['specialization']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);

    $query = "UPDATE doctors SET 
                name = '$name',
                specialization = '$specialization',
                contact = '$contact',
                email = '$email',
                department = '$department'
              WHERE id = $id";

    if (mysqli_query($conn, $query)) {
        header("Location: ../doctor.php?updated=1");
    } else {
        echo "Error updating doctor: " . mysqli_error($conn);
    }
}
?>