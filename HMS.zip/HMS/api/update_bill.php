<?php
include '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $patient_name = $_POST['patient_name'];
    $amount = $_POST['amount'];
    $bill_date = $_POST['bill_date'];
    $status = $_POST['status'];

    $query = "UPDATE billing 
              SET patient_name='$patient_name', amount='$amount', bill_date='$bill_date', status='$status' 
              WHERE id='$id'";

    if (mysqli_query($conn, $query)) {
        header("Location: ../billing.php");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
