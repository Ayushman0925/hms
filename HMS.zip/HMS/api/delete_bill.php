<?php
include '../includes/db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "DELETE FROM billing WHERE id='$id'";

    if (mysqli_query($conn, $query)) {
        header("Location: ../billing.php");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
