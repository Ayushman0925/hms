<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
include 'includes/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Nurses - Health Care</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    body, html {
      margin: 0;
      padding: 0;
      height: 100%;
    }
    #wrapper {
      display: flex;
      height: 100vh;
      overflow: hidden;
    }
    #sidebar {
      width: 250px;
      background-color:rgb(42, 46, 49);
      transition: all 0.3s ease;
    }
    #wrapper.toggled #sidebar {
      margin-left: -250px;
    }
    #main-content {
      flex-grow: 1;
      padding: 0px;
      overflow-y: auto;
      width: 100%;
    }
    @media (max-width: 768px) {
      #sidebar {
        position: absolute;
        z-index: 1000;
        height: 100%;
      }
    }
  </style>
</head>
<body>
<div id="wrapper">
  <?php include 'includes/sidebar.php'; ?>

  <div id="main-content">
    <!-- Toggle Button -->
    <nav class="navbar navbar- bg-primary mb-3">
      <div class="container-fluid">
        <button class="btn btn-outline-light" id="menu-toggle">☰</button>
        <span class="navbar-brand ms-2">Nurse Management</span>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Nurses</h3>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addNurseModal">+ Add Nurse</button>
      </div>

      <input type="text" id="searchInput" class="form-control mb-3" placeholder="Search nurses...">

      <div class="table-responsive">
        <table class="table table-bordered align-middle">
          <thead class="table-light">
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Gender</th>
              <th>Contact</th>
              <th>Email</th>
              <th>Department</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $result = mysqli_query($conn, "SELECT * FROM nurses");
            $i = 1;
            while ($row = mysqli_fetch_assoc($result)) {
              echo "<tr>
                <td>{$i}</td>
                <td>{$row['name']}</td>
                <td>{$row['gender']}</td>
                <td>{$row['contact']}</td>
                <td>{$row['email']}</td>
                <td>{$row['department']}</td>
                <td>
                  <button class='btn btn-sm btn-warning editBtn'
                    data-id='{$row['id']}'
                    data-name='{$row['name']}'
                    data-gender='{$row['gender']}'
                    data-contact='{$row['contact']}'
                    data-email='{$row['email']}'
                    data-department='{$row['department']}'>Edit</button>
                  <a href='api/delete_nurse.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Delete nurse?\")'>Delete</a>
                </td>
              </tr>";
              $i++;
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Add Nurse Modal -->
<div class="modal fade" id="addNurseModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="api/add_nurse.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Nurse</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-2"><label>Name</label><input type="text" name="name" class="form-control" required></div>
        <div class="mb-2">
          <label>Gender</label>
          <select name="gender" class="form-select" required>
            <option value="">Select</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
        </div>
        <div class="mb-2"><label>Contact</label><input type="text" name="contact" class="form-control"></div>
        <div class="mb-2"><label>Email</label><input type="email" name="email" class="form-control"></div>
        <div class="mb-2"><label>Department</label><input type="text" name="department" class="form-control"></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" type="submit">Add Nurse</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Nurse Modal -->
<div class="modal fade" id="editNurseModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="api/update_nurse.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Edit Nurse</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" id="editNurseId">
        <div class="mb-2"><label>Name</label><input type="text" name="name" id="editName" class="form-control" required></div>
        <div class="mb-2">
          <label>Gender</label>
          <select name="gender" id="editGender" class="form-select" required>
            <option value="">Select</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
        </div>
        <div class="mb-2"><label>Contact</label><input type="text" name="contact" id="editContact" class="form-control"></div>
        <div class="mb-2"><label>Email</label><input type="email" name="email" id="editEmail" class="form-control"></div>
        <div class="mb-2"><label>Department</label><input type="text" name="department" id="editDepartment" class="form-control"></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" type="submit">Update Nurse</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Sidebar toggle
  document.getElementById("menu-toggle").addEventListener("click", function () {
    document.getElementById("wrapper").classList.toggle("toggled");
  });

  // Edit button handler
  document.querySelectorAll(".editBtn").forEach(button => {
    button.addEventListener("click", () => {
      document.getElementById("editNurseId").value = button.dataset.id;
      document.getElementById("editName").value = button.dataset.name;
      document.getElementById("editGender").value = button.dataset.gender;
      document.getElementById("editContact").value = button.dataset.contact;
      document.getElementById("editEmail").value = button.dataset.email;
      document.getElementById("editDepartment").value = button.dataset.department;
      new bootstrap.Modal(document.getElementById("editNurseModal")).show();
    });
  });

  // Search filter
  document.getElementById("searchInput").addEventListener("keyup", function () {
    const filter = this.value.toLowerCase();
    document.querySelectorAll("tbody tr").forEach(row => {
      row.style.display = row.innerText.toLowerCase().includes(filter) ? "" : "none";
    });
  });
</script>
</body>
</html>