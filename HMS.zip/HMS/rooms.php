<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
include 'includes/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Rooms - Health Care</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    body, html {
      margin: 0;
      padding: 0;
      height: 100%;
    }
    #wrapper {
      display: flex;
      height: 100vh;
      overflow: hidden;
    }
    #sidebar {
      width: 250px;
      background-color:rgb(42, 46, 49);
      transition: all 0.3s ease;
    }
    #wrapper.toggled #sidebar {
      margin-left: -250px;
    }
    #main-content {
      flex-grow: 1;
      padding: 0px;
      overflow-y: auto;
      width: 100%;
    }
    @media (max-width: 768px) {
      #sidebar {
        position: absolute;
        z-index: 1000;
        height: 100%;
      }
    }
  </style>
</head>
<body>
<div id="wrapper">
  <?php include 'includes/sidebar.php'; ?>

  <div id="main-content">
    <nav class="navbar navbar- bg-primary mb-3">
      <div class="container-fluid">
        <button class="btn btn-outline-light" id="menu-toggle">☰</button>
        <span class="navbar-brand ms-2">Room Management</span>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Rooms</h3>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addRoomModal">+ Add Room</button>
      </div>

      <input type="text" id="searchInput" class="form-control mb-3" placeholder="Search rooms...">

      <div class="table-responsive">
        <table class="table table-bordered align-middle">
          <thead class="table-light">
            <tr>
              <th>#</th>
              <th>Room Number</th>
              <th>Type</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $result = mysqli_query($conn, "SELECT * FROM rooms");
            $i = 1;
            while ($row = mysqli_fetch_assoc($result)) {
              echo "<tr>
                <td>{$i}</td>
                <td>{$row['room_number']}</td>
                <td>{$row['room_type']}</td>
                <td>{$row['status']}</td>
                <td>
                  <button class='btn btn-sm btn-warning editBtn'
                    data-id='{$row['id']}'
                    data-room_number='{$row['room_number']}'
                    data-room_type='{$row['room_type']}'
                    data-status='{$row['status']}'>Edit</button>
                  <a href='api/delete_room.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Delete this room?\")'>Delete</a>
                </td>
              </tr>";
              $i++;
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Add Room Modal -->
<div class="modal fade" id="addRoomModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="api/add_room.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Room</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-2"><label>Room Number</label><input type="text" name="room_number" class="form-control" required></div>
        <div class="mb-2"><label>Room Type</label><input type="text" name="room_type" class="form-control" required></div>
        <div class="mb-2"><label>Status</label>
          <select name="status" class="form-select" required>
            <option value="Available">Available</option>
            <option value="Occupied">Occupied</option>
            <option value="Maintenance">Maintenance</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" type="submit">Add Room</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Room Modal -->
<div class="modal fade" id="editRoomModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="api/update_room.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Edit Room</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" id="editRoomId">
        <div class="mb-2"><label>Room Number</label><input type="text" name="room_number" id="editRoomNumber" class="form-control" required></div>
        <div class="mb-2"><label>Room Type</label><input type="text" name="room_type" id="editRoomType" class="form-control" required></div>
        <div class="mb-2"><label>Status</label>
          <select name="status" id="editStatus" class="form-select" required>
            <option value="Available">Available</option>
            <option value="Occupied">Occupied</option>
            <option value="Maintenance">Maintenance</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" type="submit">Update Room</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Sidebar toggle
  document.getElementById("menu-toggle").addEventListener("click", function () {
    document.getElementById("wrapper").classList.toggle("toggled");
  });

  // Edit button
  document.querySelectorAll(".editBtn").forEach(button => {
    button.addEventListener("click", () => {
      document.getElementById("editRoomId").value = button.dataset.id;
      document.getElementById("editRoomNumber").value = button.dataset.room_number;
      document.getElementById("editRoomType").value = button.dataset.room_type;
      document.getElementById("editStatus").value = button.dataset.status;
      new bootstrap.Modal(document.getElementById("editRoomModal")).show();
    });
  });

  // Search filter
  document.getElementById("searchInput").addEventListener("keyup", function () {
    const filter = this.value.toLowerCase();
    document.querySelectorAll("tbody tr").forEach(row => {
      row.style.display = row.innerText.toLowerCase().includes(filter) ? "" : "none";
    });
  });
</script>
</body>
</html>