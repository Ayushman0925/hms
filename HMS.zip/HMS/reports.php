<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
include 'includes/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reports - Health Care</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    body, html {
      margin: 0;
      padding: 0;
      height: 100%;
    }
    #wrapper {
      display: flex;
      height: 100vh;
      overflow: hidden;
    }
    #sidebar {
      width: 250px;
      background-color: rgb(42, 46, 49);
      transition: all 0.3s ease;
    }
    #wrapper.toggled #sidebar {
      margin-left: -250px;
    }
    #main-content {
      flex-grow: 1;
      padding: 0px;
      overflow-y: auto;
      width: 100%;
    }
    @media (max-width: 768px) {
      #sidebar {
        position: absolute;
        z-index: 1000;
        height: 100%;
      }
    }
  </style>
</head>
<body>
<div id="wrapper">
  <?php include 'includes/sidebar.php'; ?>

  <div id="main-content">
    <nav class="navbar navbar- bg-primary mb-3">
      <div class="container-fluid">
        <button class="btn btn-outline-light" id="menu-toggle">☰</button>
        <span class="navbar-brand ms-2">Reports</span>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Reports</h3>
        <!-- You can replace this with export buttons -->
        <button class="btn btn-secondary" onclick="window.print()">🖨 Print</button>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addReportModal">+ Add Report</button>
      </div>

      <!-- Add Report Modal -->
<div class="modal fade" id="addReportModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="api/add_report.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Report</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-2"><label>Patient ID</label><input type="number" name="patient_id" class="form-control" required></div>
        <div class="mb-2"><label>Doctor ID</label><input type="number" name="doctor_id" class="form-control" required></div>
        <div class="mb-2"><label>Report Type</label><input type="text" name="report_type" class="form-control" required></div>
        <div class="mb-2"><label>Report Date</label><input type="date" name="report_date" class="form-control" required></div>
        <div class="mb-2"><label>Description</label><textarea name="description" class="form-control" rows="3"></textarea></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" type="submit">Add Report</button>
      </div>
    </form>
  </div>
</div>


      


      <input type="text" id="searchInput" class="form-control mb-3" placeholder="Search reports...">

      <div class="table-responsive">
        <table class="table table-bordered align-middle">
          <thead class="table-light">
            <tr>
              <th>#</th>
              <th>Report Type</th>
              <th>Patient Name</th>
              <th>Date</th>
              <th>Description</th>
              <th>Doctor</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $query = "SELECT reports.*, patients.name AS patient_name, doctors.name AS doctor_name 
                      FROM reports 
                      LEFT JOIN patients ON reports.patient_id = patients.id 
                      LEFT JOIN doctors ON reports.doctor_id = doctors.id";
            $result = mysqli_query($conn, $query);
            $i = 1;
            while ($row = mysqli_fetch_assoc($result)) {
              echo "<tr>
                <td>{$i}</td>
                <td>{$row['report_type']}</td>
                <td>{$row['patient_name']}</td>
                <td>{$row['report_date']}</td>
                <td>{$row['description']}</td>
                <td>{$row['doctor_name']}</td>
                <td>
                  <a href='api/delete_report.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Delete this report?\")'>Delete</a>
                </td>
              </tr>";
              $i++;
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Sidebar toggle
  document.getElementById("menu-toggle").addEventListener("click", function () {
    document.getElementById("wrapper").classList.toggle("toggled");
  });

  // Search filter
  document.getElementById("searchInput").addEventListener("keyup", function () {
    const filter = this.value.toLowerCase();
    document.querySelectorAll("tbody tr").forEach(row => {
      row.style.display = row.innerText.toLowerCase().includes(filter) ? "" : "none";
    });
  });

  
</script>
</body>
</html>
