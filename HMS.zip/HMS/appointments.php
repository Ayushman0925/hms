<?php

session_start();

if (!isset($_SESSION['user'])) {

    header("Location: login.php");

    exit();

}

include 'includes/db.php';

?>

<!DOCTYPE html>

<html lang="en">

<head>

  <meta charset="UTF-8">

  <title>Appointments - Health Care</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

  <style>

    body, html {

      margin: 0;

      padding: 0;

      height: 100%;

    }

    #wrapper {

      display: flex;

      height: 100vh;

      overflow: hidden;

    }

    #sidebar {

      width: 250px;

      background-color:rgb(42, 46, 49);

      transition: all 0.3s ease;

    }

    #wrapper.toggled #sidebar {

      margin-left: -250px;

    }

    #main-content {

      flex-grow: 1;

      padding: 0px;

      overflow-y: auto;

      width: 100%;

    }

    @media (max-width: 768px) {

      #sidebar {

        position: absolute;

        z-index: 1000;

        height: 100%;

      }

    }

  </style>

</head>

<body>

<div id="wrapper">

  <?php include 'includes/sidebar.php'; ?>



  <div id="main-content">

    <nav class="navbar navbar- bg-primary mb-3">

      <div class="container-fluid">

        <button class="btn btn-outline-light" id="menu-toggle">☰</button>

        <span class="navbar-brand ms-2">Appointment Management</span>

      </div>

    </nav>



    <div class="container-fluid">

      <div class="d-flex justify-content-between align-items-center mb-3">

        <h3>Appointments</h3>

        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAppointmentModal">+ Add Appointment</button>

      </div>



      <input type="text" id="searchInput" class="form-control mb-3" placeholder="Search appointments...">



      <div class="table-responsive">

        <table class="table table-bordered align-middle">

          <thead class="table-light">

            <tr>

              <th>#</th>

              <th>Patient Name</th>

              <th>Doctor Name</th>

              <th>Date</th>

              <th>Time</th>

              <th>Reason</th>

              <th>Actions</th>

            </tr>

          </thead>

          <tbody>

            <?php

            $result = mysqli_query($conn, "SELECT * FROM appointments");

            $i = 1;

            while ($row = mysqli_fetch_assoc($result)) {

              echo "<tr>

                <td>{$i}</td>

                <td>{$row['patient_name']}</td>

                <td>{$row['doctor_name']}</td>

                <td>{$row['appointment_date']}</td>

                <td>{$row['appointment_time']}</td>

                <td>{$row['reason']}</td>

                <td>

                  <button class='btn btn-sm btn-warning editBtn'

                    data-id='{$row['id']}'

                    data-patient_name='{$row['patient_name']}'

                    data-doctor_name='{$row['doctor_name']}'

                    data-appointment_date='{$row['appointment_date']}'

                    data-appointment_time='{$row['appointment_time']}'

                    data-reason='{$row['reason']}'>Edit</button>

                  <a href='api/delete_appointment.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Delete appointment?\")'>Delete</a>

                </td>

              </tr>";

              $i++;

            }

            ?>

          </tbody>

        </table>

      </div>

    </div>

  </div>

</div>



<!-- Add Appointment Modal -->

<div class="modal fade" id="addAppointmentModal" tabindex="-1">

  <div class="modal-dialog">

    <form action="api/add_appointment.php" method="POST" class="modal-content">

      <div class="modal-header">

        <h5 class="modal-title">Add Appointment</h5>

        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>

      </div>

      <div class="modal-body">

        <div class="mb-2"><label>Patient Name</label><input type="text" name="patient_name" class="form-control" required></div>

        <div class="mb-2"><label>Doctor Name</label><input type="text" name="doctor_name" class="form-control" required></div>

        <div class="mb-2"><label>Date</label><input type="date" name="appointment_date" class="form-control" required></div>

        <div class="mb-2"><label>Time</label><input type="time" name="appointment_time" class="form-control" required></div>

        <div class="mb-2"><label>Reason</label><textarea name="reason" class="form-control" rows="2"></textarea></div>

      </div>

      <div class="modal-footer">

        <button class="btn btn-success" type="submit">Add Appointment</button>

      </div>

    </form>

  </div>

</div>



<!-- Edit Appointment Modal -->

<div class="modal fade" id="editAppointmentModal" tabindex="-1">

  <div class="modal-dialog">

    <form action="api/update_appointment.php" method="POST" class="modal-content">

      <div class="modal-header">

        <h5 class="modal-title">Edit Appointment</h5>

        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>

      </div>

      <div class="modal-body">

        <input type="hidden" name="id" id="editId">

        <div class="mb-2"><label>Patient Name</label><input type="text" name="patient_name" id="editPatientName" class="form-control" required></div>

        <div class="mb-2"><label>Doctor Name</label><input type="text" name="doctor_name" id="editDoctorName" class="form-control" required></div>

        <div class="mb-2"><label>Date</label><input type="date" name="appointment_date" id="editDate" class="form-control" required></div>

        <div class="mb-2"><label>Time</label><input type="time" name="appointment_time" id="editTime" class="form-control" required></div>

        <div class="mb-2"><label>Reason</label><textarea name="reason" id="editReason" class="form-control" rows="2"></textarea></div>

      </div>

      <div class="modal-footer">

        <button class="btn btn-success" type="submit">Update Appointment</button>

      </div>

    </form>

  </div>

</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>

  document.getElementById("menu-toggle").addEventListener("click", function () {

    document.getElementById("wrapper").classList.toggle("toggled");

  });



  document.querySelectorAll(".editBtn").forEach(button => {

    button.addEventListener("click", () => {

      document.getElementById("editId").value = button.dataset.id;

      document.getElementById("editPatientName").value = button.dataset.patient_name;

      document.getElementById("editDoctorName").value = button.dataset.doctor_name;

      document.getElementById("editDate").value = button.dataset.appointment_date;

      document.getElementById("editTime").value = button.dataset.appointment_time;

      document.getElementById("editReason").value = button.dataset.reason;

      new bootstrap.Modal(document.getElementById("editAppointmentModal")).show();

    });

  });



  document.getElementById("searchInput").addEventListener("keyup", function () {

    const filter = this.value.toLowerCase();

    document.querySelectorAll("tbody tr").forEach(row => {

      row.style.display = row.innerText.toLowerCase().includes(filter) ? "" : "none";

    });

  });

</script>

</body>

</html>