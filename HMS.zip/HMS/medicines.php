<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
include 'includes/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Medicines - Health Care</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    body, html {
      margin: 0;
      padding: 0;
      height: 100%;
    }
    #wrapper {
      display: flex;
      height: 100vh;
      overflow: hidden;
    }
    #sidebar {
      width: 250px;
      background-color: rgb(42, 46, 49);
      transition: all 0.3s ease;
    }
    #wrapper.toggled #sidebar {
      margin-left: -250px;
    }
    #main-content {
      flex-grow: 1;
      padding: 0px;
      overflow-y: auto;
      width: 100%;
    }
    #menu-toggle {
      cursor: pointer;
    }
    @media (max-width: 768px) {
      #sidebar {
        position: absolute;
        z-index: 1000;
        height: 100%;
      }
    }
  </style>
</head>
<body>
<div id="wrapper">
  <?php include 'includes/sidebar.php'; ?>

  <div id="main-content">
    <nav class="navbar navbar-expand-lg bg-primary mb-3">
      <div class="container-fluid">
        <button class="btn btn-outline-light" id="menu-toggle">☰</button>
        <span class="navbar-brand ms-2 text-white">Medicine Management</span>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Medicines</h3>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMedicineModal">+ Add Medicine</button>
      </div>

      <input type="text" id="searchInput" class="form-control mb-3" placeholder="Search medicines...">

      <div class="table-responsive">
        <table class="table table-bordered align-middle">
          <thead class="table-light">
            <tr>
              <th>#</th>
              <th>Medicine Name</th>
              <th>Type</th>
              <th>Manufacturer</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $result = mysqli_query($conn, "SELECT * FROM medicines");
            $i = 1;
            while ($row = mysqli_fetch_assoc($result)) {
              echo "<tr>
                <td>{$i}</td>
                <td>{$row['name']}</td>
                <td>{$row['type']}</td>
                <td>{$row['manufacturer']}</td>
                <td>{$row['price']}</td>
                <td>{$row['stock']}</td>
                <td>
                  <button class='btn btn-sm btn-warning editBtn'
                    data-id='{$row['id']}'
                    data-name='{$row['name']}'
                    data-type='{$row['type']}'
                    data-manufacturer='{$row['manufacturer']}'
                    data-price='{$row['price']}'
                    data-stock='{$row['stock']}'>Edit</button>
                  <a href='api/delete_medicine.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Delete medicine?\")'>Delete</a>
                </td>
              </tr>";
              $i++;
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Add Medicine Modal -->
<div class="modal fade" id="addMedicineModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="api/add_medicine.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Medicine</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-2"><label>Name</label><input type="text" name="name" class="form-control" required></div>
        <div class="mb-2"><label>Type</label><input type="text" name="type" class="form-control"></div>
        <div class="mb-2"><label>Manufacturer</label><input type="text" name="manufacturer" class="form-control"></div>
        <div class="mb-2"><label>Price</label><input type="number" step="0.01" name="price" class="form-control" required></div>
        <div class="mb-2"><label>Stock</label><input type="number" name="stock" class="form-control" required></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" type="submit">Add Medicine</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Medicine Modal -->
<div class="modal fade" id="editMedicineModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="api/update_medicine.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Edit Medicine</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" id="editMedicineId">
        <div class="mb-2"><label>Name</label><input type="text" name="name" id="editName" class="form-control" required></div>
        <div class="mb-2"><label>Type</label><input type="text" name="type" id="editType" class="form-control"></div>
        <div class="mb-2"><label>Manufacturer</label><input type="text" name="manufacturer" id="editManufacturer" class="form-control"></div>
        <div class="mb-2"><label>Price</label><input type="number" step="0.01" name="price" id="editPrice" class="form-control" required></div>
        <div class="mb-2"><label>Stock</label><input type="number" name="stock" id="editStock" class="form-control" required></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" type="submit">Update Medicine</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Sidebar toggle
  document.getElementById("menu-toggle").addEventListener("click", function () {
    document.getElementById("wrapper").classList.toggle("toggled");
  });

  // Edit button handler
  document.querySelectorAll(".editBtn").forEach(button => {
    button.addEventListener("click", () => {
      document.getElementById("editMedicineId").value = button.dataset.id;
      document.getElementById("editName").value = button.dataset.name;
      document.getElementById("editType").value = button.dataset.type;
      document.getElementById("editManufacturer").value = button.dataset.manufacturer;
      document.getElementById("editPrice").value = button.dataset.price;
      document.getElementById("editStock").value = button.dataset.stock;
      new bootstrap.Modal(document.getElementById("editMedicineModal")).show();
    });
  });

  // Search filter
  document.getElementById("searchInput").addEventListener("keyup", function () {
    const filter = this.value.toLowerCase();
    document.querySelectorAll("tbody tr").forEach(row => {
      row.style.display = row.innerText.toLowerCase().includes(filter) ? "" : "none";
    });
  });
</script>
</body>
</html>

