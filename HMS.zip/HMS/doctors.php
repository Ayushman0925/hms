<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
include 'includes/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Doctors - Health Care</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    body, html {
      margin: 0;
      padding: 0;
      height: 100%;
    }
    #wrapper {
      display: flex;
      height: 100vh;
      overflow: hidden;
    }
    #sidebar {
      width: 250px;
      background-color:rgb(42, 46, 49);
      transition: all 0.3s ease;
    }
    #wrapper.toggled #sidebar {
      margin-left: -250px;
    }
    #main-content {
      flex-grow: 1;
      padding: 0px;
      overflow-y: auto;
      width: 100%;
    }
    @media (max-width: 768px) {
      #sidebar {
        position: absolute;
        z-index: 1000;
        height: 100%;
      }
    }
  </style>
</head>
<body>
<div id="wrapper">
  <?php include 'includes/sidebar.php'; ?>

  <div id="main-content">
    <nav class="navbar navbar- bg-primary mb-3">
      <div class="container-fluid">
        <button class="btn btn-outline-light" id="menu-toggle">☰</button>
        <span class="navbar-brand ms-2">Doctor Management</span>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Doctors</h3>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addDoctorModal">+ Add Doctor</button>
      </div>

      <input type="text" id="searchInput" class="form-control mb-3" placeholder="Search doctors...">

      <div class="table-responsive">
        <table class="table table-bordered align-middle">
          <thead class="table-light">
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Specialization</th>
              <th>Contact</th>
              <th>Email</th>
              <th>Department</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $result = mysqli_query($conn, "SELECT * FROM doctors");
            $i = 1;
            while ($row = mysqli_fetch_assoc($result)) {
              echo "<tr>
                <td>{$i}</td>
                <td>{$row['name']}</td>
                <td>{$row['specialization']}</td>
                <td>{$row['contact']}</td>
                <td>{$row['email']}</td>
                <td>{$row['department']}</td>
                <td>
                  <button class='btn btn-sm btn-warning editBtn'
                    data-id='{$row['id']}'
                    data-name='{$row['name']}'
                    data-specialization='{$row['specialization']}'
                    data-contact='{$row['contact']}'
                    data-email='{$row['email']}'
                    data-department='{$row['department']}'>Edit</button>
                  <a href='api/delete_doctor.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Delete doctor?\")'>Delete</a>
                </td>
              </tr>";
              $i++;
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Add Doctor Modal -->
<div class="modal fade" id="addDoctorModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="api/add_doctor.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Doctor</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-2"><label>Name</label><input type="text" name="name" class="form-control" required></div>
        <div class="mb-2"><label>Specialization</label><input type="text" name="specialization" class="form-control" required></div>
        <div class="mb-2"><label>Contact</label><input type="text" name="contact" class="form-control"></div>
        <div class="mb-2"><label>Email</label><input type="email" name="email" class="form-control"></div>
        <div class="mb-2"><label>Department</label><input type="text" name="department" class="form-control"></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" type="submit">Add Doctor</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Doctor Modal -->
<div class="modal fade" id="editDoctorModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="api/update_doctor.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Edit Doctor</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" id="editDoctorId">
        <div class="mb-2"><label>Name</label><input type="text" name="name" id="editName" class="form-control" required></div>
        <div class="mb-2"><label>Specialization</label><input type="text" name="specialization" id="editSpecialization" class="form-control" required></div>
        <div class="mb-2"><label>Contact</label><input type="text" name="contact" id="editContact" class="form-control"></div>
        <div class="mb-2"><label>Email</label><input type="email" name="email" id="editEmail" class="form-control"></div>
        <div class="mb-2"><label>Department</label><input type="text" name="department" id="editDepartment" class="form-control"></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" type="submit">Update Doctor</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Sidebar toggle
  document.getElementById("menu-toggle").addEventListener("click", function () {
    document.getElementById("wrapper").classList.toggle("toggled");
  });

  // Edit button handler
  document.querySelectorAll(".editBtn").forEach(button => {
    button.addEventListener("click", () => {
      document.getElementById("editDoctorId").value = button.dataset.id;
      document.getElementById("editName").value = button.dataset.name;
      document.getElementById("editSpecialization").value = button.dataset.specialization;
      document.getElementById("editContact").value = button.dataset.contact;
      document.getElementById("editEmail").value = button.dataset.email;
      document.getElementById("editDepartment").value = button.dataset.department;
      new bootstrap.Modal(document.getElementById("editDoctorModal")).show();
    });
  });

  // Search filter
  document.getElementById("searchInput").addEventListener("keyup", function () {
    const filter = this.value.toLowerCase();
    document.querySelectorAll("tbody tr").forEach(row => {
      row.style.display = row.innerText.toLowerCase().includes(filter) ? "" : "none";
    });
  });
</script>
</body>
</html>