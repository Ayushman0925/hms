<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
include 'includes/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - HMS</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    #sidebar { width: 220px; position: fixed; top: 0; left: 0; height: 100vh; }
    #main-content { margin-left: 220px; padding: 20px; }
  </style>
</head>
<body>

<?php include 'includes/sidebar.php'; ?>
<?php include 'includes/header.php'; ?>

<div id="main-content">
  <h3>Welcome, <?= htmlspecialchars($_SESSION['user']['username']) ?>!</h3>
  <div class="row mt-4">
    <div class="col-md-3">
      <div class="card bg-success text-white">
        <div class="card-body">
          <h5>Total Patients</h5>
          <p class="display-6">--</p>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card bg-info text-white">
        <div class="card-body">
          <h5>Total Doctors</h5>
          <p class="display-6">--</p>
        </div>
      </div>
    </div>
    <!-- Add more cards like Appointments, Rooms etc -->
  </div>
</div>

</body>
</html>