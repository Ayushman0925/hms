<!-- includes/sidebar.php -->

<div class="bg-dark text-white vh-100 p-3" id="sidebar">

  <h4 class="text-center">🏥 Health Care</h4>

  <ul class="nav flex-column mt-4">

    <li class="nav-item"><a class="nav-link text-white" href="dashboard.php">📊 Dashboard</a></li>

    <li class="nav-item"><a class="nav-link text-white" href="patients.php">🧑‍🤝‍🧑 Patients</a></li>

    <li class="nav-item"><a class="nav-link text-white" href="doctors.php">🧑‍⚕ Doctors</a></li>

    <li class="nav-item"><a class="nav-link text-white" href="nurse.php">🧑‍⚕ Nurse</a></li>

    <li class="nav-item"><a class="nav-link text-white" href="appointments.php">📅 Appointments</a></li>

    <li class="nav-item"><a class="nav-link text-white" href="rooms.php">🏥 Rooms</a></li>

    <li class="nav-item"><a class="nav-link text-white" href="medicines.php">💊 Medicines</a></li>

    <li class="nav-item"><a class="nav-link text-white" href="billing.php">💵 Billing</a></li>

    <li class="nav-item"><a class="nav-link text-white" href="reports.php">📄 Reports</a></li>

    <li class="nav-item"><a class="nav-link text-white" href="logout.php">🚪 Logout</a></li>

  </ul>

</div>