<footer class="text-center mt-5 p-3 bg-light border-top">
  <small>© <?= date("Y") ?> Health Care Management System. All rights reserved.</small>
</footer>