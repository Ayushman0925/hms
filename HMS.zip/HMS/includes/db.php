<?php
$host = "localhost";
$user = "root"; // default for XAMPP
$pass = "";     // empty by default
$db   = "hospital_management";

$conn = mysqli_connect($host, $user, $pass, $db);

// ✅ Handle connection error
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>