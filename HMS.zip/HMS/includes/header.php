<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    
    <!-- Sidebar toggle button -->
    <button class="btn btn-outline-light me-2" id="sidebarToggle">☰</button>

    <!-- Brand -->
    <a class="navbar-brand" href="dashboard.php">🏥 Health Care</a>

    <!-- Collapsible content -->
    <div class="collapse navbar-collapse justify-content-end">
      <ul class="navbar-nav">
        <?php if (isset($_SESSION['user'])): ?>
          <li class="nav-item">
            <a class="nav-link" href="#">
              👤 <?= htmlspecialchars($_SESSION['user']['username']) ?>
              (<?= ucfirst(htmlspecialchars($_SESSION['user']['role'])) ?>)
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="logout.php">Logout</a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>