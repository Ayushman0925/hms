<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
include 'includes/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Billing - Health Care</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    body, html {
      margin: 0;
      padding: 0;
      height: 100%;
    }
    #wrapper {
      display: flex;
      height: 100vh;
      overflow: hidden;
    }
    #sidebar {
      width: 250px;
      background-color: rgb(42, 46, 49);
      transition: all 0.3s ease;
    }
    #wrapper.toggled #sidebar {
      margin-left: -250px;
    }
    #main-content {
      flex-grow: 1;
      padding: 0px;
      overflow-y: auto;
      width: 100%;
    }
    #menu-toggle {
      cursor: pointer;
    }
    @media (max-width: 768px) {
      #sidebar {
        position: absolute;
        z-index: 1000;
        height: 100%;
      }
    }
  </style>
</head>
<body>
<div id="wrapper">
  <?php include 'includes/sidebar.php'; ?>

  <div id="main-content">
    <nav class="navbar navbar-expand-lg bg-primary mb-3">
      <div class="container-fluid">
        <button class="btn btn-outline-light" id="menu-toggle">☰</button>
        <span class="navbar-brand ms-2 text-white">Billing</span>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Patient Billing</h3>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addBillModal">+ Add Bill</button>
      </div>

      <div class="table-responsive">
        <table class="table table-bordered align-middle">
          <thead class="table-light">
            <tr>
              <th>#</th>
              <th>Patient Name</th>
              <th>Total Amount</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $result = mysqli_query($conn, "SELECT * FROM billing");
            $i = 1;
            while ($row = mysqli_fetch_assoc($result)) {
              echo "<tr>
                <td>{$i}</td>
                <td>{$row['patient_name']}</td>
                <td>{$row['amount']}</td>
                <td>{$row['date']}</td>
                <td>
                  <button class='btn btn-sm btn-warning editBtn'
                    data-id='{$row['id']}'
                    data-name='{$row['patient_name']}'
                    data-amount='{$row['amount']}'
                    data-date='{$row['date']}'>Edit</button>
                  <a href='api/delete_bill.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Delete bill?\")'>Delete</a>
                </td>
              </tr>";
              $i++;
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Add Bill Modal -->
<div class="modal fade" id="addBillModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="api/add_bill.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Bill</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-2"><label>Patient Name</label><input type="text" name="patient_name" class="form-control" required></div>
        <div class="mb-2"><label>Total Amount</label><input type="number" step="0.01" name="amount" class="form-control" required></div>
        <div class="mb-2"><label>Date</label><input type="date" name="date" class="form-control" required></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" type="submit">Add Bill</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Bill Modal -->
<div class="modal fade" id="editBillModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="api/update_bill.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Edit Bill</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" id="editBillId">
        <div class="mb-2"><label>Patient Name</label><input type="text" name="patient_name" id="editPatientName" class="form-control" required></div>
        <div class="mb-2"><label>Total Amount</label><input type="number" step="0.01" name="amount" id="editAmount" class="form-control" required></div>
        <div class="mb-2"><label>Date</label><input type="date" name="date" id="editDate" class="form-control" required></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" type="submit">Update Bill</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Sidebar toggle
  document.getElementById("menu-toggle").addEventListener("click", function () {
    document.getElementById("wrapper").classList.toggle("toggled");
  });

  // Edit button handler
  document.querySelectorAll(".editBtn").forEach(button => {
    button.addEventListener("click", () => {
      document.getElementById("editBillId").value = button.dataset.id;
      document.getElementById("editPatientName").value = button.dataset.name;
      document.getElementById("editAmount").value = button.dataset.amount;
      document.getElementById("editDate").value = button.dataset.date;
      new bootstrap.Modal(document.getElementById("editBillModal")).show();
    });
  });
</script>
</body>
</html>
